package com.ayush.steganography;

import java.math.BigInteger;

public class rsa_decrypt {

    public String decryptText(String cipherText, BigInteger d, BigInteger n) {

        String plainText = "";
        String[] arrOfStr = cipherText.split(" ", plainText.length());

        for (String a : arrOfStr) {
            BigInteger ascii = new BigInteger(a);
            BigInteger p = ascii.modPow(d, n);
            plainText = plainText + (char)(p.intValue());
        }

        return plainText;

    }

}
