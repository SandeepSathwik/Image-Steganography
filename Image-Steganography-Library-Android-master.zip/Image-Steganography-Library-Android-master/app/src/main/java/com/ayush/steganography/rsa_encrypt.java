package com.ayush.steganography;

import java.math.BigInteger;
import java.util.Random;

public class rsa_encrypt {
    int bitLength = 5;
    public BigInteger zero = BigInteger.ZERO, one = BigInteger.ONE;
    public BigInteger n = zero, e = zero, d = zero;
    BigInteger p = BigInteger.probablePrime(bitLength, new Random());
    BigInteger q = BigInteger.probablePrime(bitLength, new Random());

    public rsa_encrypt() {
        // TODO Auto-generated constructor stub
        while ((p.gcd(q)).compareTo(one)!=0) {
            p = BigInteger.probablePrime(bitLength, new Random());
            q = BigInteger.probablePrime(bitLength, new Random());
        }

        n = p.multiply(q);
        e = publicKey(p, q);
        d = privateKey(e, p, q);
    }

    public BigInteger publicKey(BigInteger p, BigInteger q) {

        BigInteger findE = (p.subtract(one)).multiply(q.subtract(one));
        BigInteger e = BigInteger.valueOf(2);

        while(e.compareTo(findE)==-1) {

            if((e.gcd(findE)).compareTo(one)==0)

                return e;

            e = e.add(one);

        }return e;

    }

    public String encryptText(String plainText, BigInteger e, BigInteger n) {

        String cipherText = "";

        for(int i =0; i<plainText.length(); i++) {

            char character = plainText.charAt(i);
            BigInteger ascii = BigInteger.valueOf((int) character);
            BigInteger c = ascii.modPow(e, n);
//			cipherText = cipherText + (char)(c.intValue());
            cipherText = cipherText + c.toString() + " ";

        }

        return cipherText;

    }

    public BigInteger privateKey(BigInteger e, BigInteger p, BigInteger q) {

        BigInteger findD = (p.subtract(one)).multiply(q.subtract(one));
        BigInteger d = e.modInverse(findD);

        return d;

    }
}
